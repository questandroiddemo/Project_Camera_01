package com.example.cameraserviceinterface.constants;

public class CameraHmiServiceConstant {

}
