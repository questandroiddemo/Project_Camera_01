package Presenter;

public class PresenterCamera {
}
