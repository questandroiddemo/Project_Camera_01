package com.example.project_camera_01;

public class DataModel {


    public String name;
    public boolean checked;
//    boolean checked;


    public DataModel(String name, boolean checked) {
        this.name = name;
        this.checked = checked;

    }

}
